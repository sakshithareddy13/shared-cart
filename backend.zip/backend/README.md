# Backend

Contains the Supabase project (database migrations, config, edge-function scaffolding) and the server-only source files extracted from the app.

- `supabase/` — Supabase migrations & config
- `server-src/` — TanStack Start server functions & Supabase server clients
- `.env` — environment variables (Supabase URL/keys)

These files originally lived inside the fullstack TanStack Start project. To run standalone, they need to be wired back into a server host.
